function wr = chaser_Dan(wr,t2,time)
    % wr is chaster
    % t2 is evader

    %% Tunables
    algo_params.r_close = 600;
    algo_params.r_far = inf;

    % Turn angles (0 <= angle_fwd < angle_slide <= pi/2)
    turn_params.angle_fwd = deg2rad(8);
    turn_params.angle_slide = deg2rad(45);

    turn_params.slide_ratio = 0.80;   % For Slide turns
    u_max = 150;

    %% Arena Boundary
    offset = 150; % mm offset from corner
    boundary_point = [400+offset,2200-offset;
                      400+offset,400+offset;
                      3200-offset,400+offset;
                      4400-offset,1300;
                      4400-offset,2200-offset];
    boundary_point = boundary_point.';

    %% Unpack State
    % Position
    r_evader = [t2.pos(1);t2.pos(2)];
    r_current = [wr.pos(1);wr.pos(2)];

    r_evader_rel = r_evader - r_current;
    r_dist = norm(r_evader_rel,2);

    % Heading
    % theta_current = atan2(wr.heading_vec(2),wr.heading_vec(1));
    % theta_evader = atan2(t2.heading_vec(2),t2.heading_vec(1));
    theta_current = wr.heading;
    theta_evader = wr.evader_heading;

    %% Chasing Algorithm
    fprintf("\nChaser: ");
    if r_dist < algo_params.r_close
        %% Final Approach Algorithm 
        fprintf("Final Approach...");

        % r_evader_predict = r_evader; 
        r_evader_predict = r_evader + wr.evader_velocity*2; 
        % r_evader_predict = r_evader +  [cos(theta_evader); ...
        %                                 sin(theta_evader)] * 200; % Predict where the evader is based on speed? or just a 200 mm offset
        % r_evader_predict = r_evader +  [((t2.vr+t2.vl)/2) * cos(theta_evader); ...
        %                                 ((t2.vr+t2.vl)/2) * sin(theta_evader)] * time.dt; 

        % Which one is better?
        r_target = r_evader_predict; 

    elseif algo_params.r_close <= r_dist && r_dist <= algo_params.r_far
        %% Cornering Algorithm (Voronoi-based area-minimizing pursuit)
        % doi: 10.1109/LRA.2016.2645516
        fprintf("Cornering...");

        % Perpendicular bisector between chaser and evader
        r_mid = (r_current + r_evader)/2;

        r_rel = r_evader - r_current;
        n = r_rel/norm(r_rel,2);

        d = [-n(2); n(1)]; % Perp bisector vector

        % Intersections with the polygon edges
        edge = boundary_point(:,[2:end,1]) - boundary_point;
        denominator = n.'*edge;

        % Just in case if any edges are parallel
        valid = abs(denominator) > 1e-10; % Divide by 0 cases

        s = nan(1,size(boundary_point,2));
        numerator = n.'*(r_mid - boundary_point);
        s(valid) = numerator(valid)./denominator(valid); 
        valid = valid & s >= -1e-10 & s <= 1 + 1e-10; % Check for weird cases

        if any(valid)
            s_valid = max(0,min(1,s(valid)));
            intersections = boundary_point(:,valid) + edge(:,valid).*s_valid;

            lambda = d.'*(intersections - r_mid);
            r_target = r_mid + ((min(lambda) + max(lambda))/2)*d;
        else
            % Target evader directly if there is any numerical issues
            r_target = r_evader;
        end
    else
        %% Long-Range Tracking
        fprintf("Long-Range...");

        r_target = r_evader;
    end

    %% Convert Target Position to Control Input
    r_target_rel = r_target - r_current;
    theta_target = atan2(r_target_rel(2),r_target_rel(1));
    theta_target_rel = wrapToPi(theta_target - theta_current);

    % Forward or Reverse
    drive_direction = 1;
    if abs(theta_target_rel) > pi/2
        % Reverse Direction
        drive_direction = -1;
        theta_target_rel = wrapToPi(theta_target_rel - pi);
    end
    angle_error = abs(theta_target_rel);

    % Signed wheel commands
    pwm_drive = double(u_max);
    pwm_left  = drive_direction*pwm_drive;
    pwm_right = drive_direction*pwm_drive;

    % Check if we need to turn
    if angle_error > turn_params.angle_slide
        fprintf("Turning");

        % Point Turn
        pwm_left  = -sign(theta_target_rel)*pwm_drive;
        pwm_right = -pwm_left;
    elseif angle_error > turn_params.angle_fwd
        fprintf("To Our Oblique");

        % Slide Turn
        if drive_direction*theta_target_rel > 0
            pwm_left  = drive_direction*turn_params.slide_ratio*pwm_drive;
            pwm_right = drive_direction*pwm_drive;
        else
            pwm_left  = drive_direction*pwm_drive;
            pwm_right = drive_direction*turn_params.slide_ratio*pwm_drive;
        end
    else
        fprintf("Dead Ahead");
    end

    % Convert signed commands to direction and magnitude
    wr.DIRL = double(pwm_left  >= 0);
    wr.DIRR = double(pwm_right >= 0);
    wr.PWML = abs(pwm_left);
    wr.PWMR = abs(pwm_right);

    %   setting the PWM limits
    wr.PWML = min(150,  wr.PWML);
    wr.PWML = uint8(max(0,  wr.PWML));
    wr.PWMR = min(150,  wr.PWMR);
    wr.PWMR = uint8(max(0,  wr.PWMR));
end