function t2 = evader(wr,t2,time)
    %% Assumptions
    % wr is chaser
    % t2 is evader
    %% Establish variables for all codes
    % Find headings [rads]
    % Chaser
    chaserHeadingVector = [ ...
        wr.front_marker(1) - wr.back_marker(1); ...
        wr.front_marker(2) - wr.back_marker(2)];
    theta_chaser = atan2( ...
        chaserHeadingVector(2), ...
        chaserHeadingVector(1));
    t2.chaser_heading = wrapToPi(theta_chaser);
    % Evader
    evaderHeadingVector = [t2.front_marker(1) - t2.back_marker(1); ...
        t2.front_marker(2) - t2.back_marker(2)];
    theta_evader = atan2( ...
        evaderHeadingVector(2), ...
        evaderHeadingVector(1));
    t2.heading = wrapToPi(theta_evader);
    % Find some other thing thats being recaculated
    t2.u_max = 150;
    t2.vr = t2.old_vr;
    t2.vl = t2.old_vl;
    %% Select which chaser algo to use
    evader = 4;

    if any(isnan(t2.pos))
        disp("Evader is NaN")
    else
        if evader == 1
            t2 = evader_Main(wr,t2,time);
        elseif evader == 2
            % t2 = EvaderSpinOnDatThang(t2,time);
            t2.DIRR = 1;
            t2.DIRL = 1;
            t2.PWMR = 150;
            t2.PWML = 90;
        elseif evader == 3 % outside loop
            offset = 200; % mm offset from corner
            corner1 = [400 + offset, 2200 - offset]; 
            corner2 = [400 + offset, 400 + offset];
            corner3 = [3200 - offset, 400 + offset];
            corner4 = [4400 - offset, 1300];
            corner5 = [4400 - offset, 2200 - offset];
            t2.WP = [corner1; corner2; corner3; corner4; corner5];
            % t2 = EvaderOutsideLoop(t2,time);
            if isempty(t2.idx)
                dist2corner = [norm(t2.pos - corner1); norm(t2.pos - corner2); ...
                    norm(t2.pos - corner3); norm(t2.pos - corner4); norm(t2.pos - corner5)];
    
                % sort corners into waypoints based on how close they are
                idx = find(min(dist2corner) == dist2corner);
                t2.idx = idx;
                t2.curWP = idx;
            end

            % control wp function
            t2 = control_wp(t2, time);
        elseif evader == 4
            t2 = evader_HesRightBehindMeIsntHe(wr, t2, time);
        else
            error('Unsupported evader algorithm: %d', evader);
        end
    end
    % disp(t2.DIRL)
    % disp(t2.DIRR)
    %% Print statements here for debugging

    %% Establish variables that are old now
    t2.old_vr = t2.vr;
    t2.old_vl = t2.vl;
    %% Setting the PWM limits
    t2.PWML = min(150,  t2.PWML);
    t2.PWML = uint8(max(0,  t2.PWML));
    t2.PWMR = min(150,  t2.PWMR);
    t2.PWMR = uint8(max(0,  t2.PWMR));
    fprintf("Current waypoint %d", t2.curWP)
end
