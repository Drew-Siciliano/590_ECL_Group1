function t2 = evader_HesRightBehindMeIsntHe(wr,t2,time)
    L = 151.2;

    R = norm(wr.pos - t2.pos);

    if t2.heading_fixed
        if (R > 300)
            t2.PWMR = 150;
            t2.PWML = 95;
    
            t2.DIRL = 1;
            t2.DIRR = 1;
        else
            t2.PWMR = 150;
            t2.PWML = 95;
    
            t2.DIRL = 0;
            t2.DIRR = 0;
        end
    else
        t2.current_heading = rad2deg(t2.heading);
        t2 = control_heading(t2, time, pi/2);
        if abs(t2.heading - pi/2) <= deg2rad(15)
            t2.heading_fixed = 1;
        end
    end